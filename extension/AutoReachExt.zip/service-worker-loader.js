import './assets/background.js-DLczdsYu.js';
