import './assets/background.js-DJ6rkfcZ.js';
